import React from 'react'

const Validate = () => {
    return (
        <div>Validate</div>
    )
}

export default Validate